[app]
title = Button And Gun
package.name = buttonandgun
package.domain = org.buttonandgun
source.dir = .
source.include_exts = py,png,ttf
version = 0.1
requirements = python3,pygame-ce
icon.filename = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/icon.png
android.presplash_color = #184634
orientation = landscape
fullscreen = 1

android.api = 33
android.minapi = 21
android.ndk = 25b
android.ndk_api = 21
android.archs = arm64-v8a
android.accept_sdk_license = True
android.allow_backup = True
android.permissions = INTERNET

p4a.branch = v2024.01.21
p4a.local_recipes = ./recipes

[buildozer]
log_level = 2
warn_on_root = 1
