#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Button And Gun - игра на двоих (Pygame), вид сверху, FULLSCREEN.

Как играть:
  * Телефон кладётся на стол. Один игрок снизу, другой сверху.
  * Нижняя половина экрана = кнопка нижнего игрока, верхняя = верхнего.
  * Жми, пока горит ЗЕЛЁНЫЙ. Красный/жёлтый - нельзя (фальстарт -> пистолет врагу).
  * Кто получил пистолет, целится во врага: 50% выстрел / 50% осечка.
  * Осечка - пистолет возвращается в центр, появляется кнопка. Выстрел - смерть.

Управление на ПК для теста: SPACE - нижний игрок, ENTER - верхний, ESC - выход.
"""
import json
import math
import os
import queue
import random
import socket
import string
import sys
import threading
import time

import pygame

pygame.init()
pygame.mouse.set_visible(False)
try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except Exception:
    screen = pygame.display.set_mode((1600, 720), pygame.SCALED | pygame.FULLSCREEN)
pygame.display.set_caption("Button And Gun")
W, H = screen.get_size()
clock = pygame.time.Clock()

# ----------------------------------------------------------------- размеры
v = min(W / 10.0, H / 16.0)          # базовая единица
CX, CY = W / 2.0, H / 2.0
SEAT = max(0.0, min(3.0 * v, H / 2.0 - 6.8 * v))   # насколько игроки подвинуты к столу
# LOCAL_PLAYER - кто "я" на этом устройстве (0 или 1). Я всегда сижу ВНИЗУ
# и вижу ТОЛЬКО СВОИ тексты. Тексты соперника скрыты.
LOCAL_PLAYER = 0
# True  - пока нет сервера: тап по верхней половине экрана жмёт за верхнего игрока
#         (чтобы можно было тестировать вдвоём на одном телефоне).
# False - онлайн: любое касание = нажатие "моего" игрока.
INPUT_BY_HALF = True
# Играть против бота (бот сидит сверху). Бота можно обыграть: он реагирует
# не мгновенно, иногда ошибается и иногда ведётся на синюю кнопку.
VS_BOT = True
ONLINE = False                      # True - матч через сервер
BOT_REACT = (0.30, 0.55)      # время реакции бота на зелёный, сек (меньше = сложнее)
BOT_ANTICIPATE = 0.07         # шанс, что бот "угадает" и нажмёт на жёлтый (фальстарт)
BOT_SEES_BLUE = 0.88          # шанс, что бот заметит синюю кнопку и не нажмёт
BOT_COMMIT = 0.30             # шанс нажать, хоть свет уже сменился с зелёного
BOT_SELF_PROB = 0.30          # шанс, что бот выстрелит в себя (если у него больше 1 жизни)
BOT_SELF_HIGH = 0.30           # шанс, что бот выстрелит в себя (если у него больше 1 жизни)
BOT_SELF_LOW = 0.12            # то же, если у бота осталась 1 жизнь
if len(sys.argv) > 1 and sys.argv[1] in ("0", "1"):
    LOCAL_PLAYER = int(sys.argv[1])
    INPUT_BY_HALF = False
    VS_BOT = False

if LOCAL_PLAYER == 1:
    EDGE = [0, H]                    # игрок 1 сидит внизу, игрок 0 - наверху
    INW = [1, -1]
else:
    EDGE = [H, 0]                    # игрок 0 внизу, игрок 1 наверху
    INW = [-1, 1]                    # направление "к центру" по оси Y

RED = (235, 45, 45)
YEL = (250, 205, 45)
GRN = (55, 225, 95)
PCOL = [(70, 140, 235), (245, 135, 55)]     # цвет игрока = цвет его крови
BODY_D = 2.9                               # центр круга-человечка от края стола (в v)
BTN = 0.78                                 # размер кнопки на столе (1.0 = как раньше)
GUN_SCALE = 0.75                           # размер пистолета (всегда один и тот же)
LANG = "en"                                # "en" или "ru" - переключается кнопкой в углу
T = {
    "play": ("Play", "Играть"),
    "help": ("Help", "Помощь"),
    "exit": ("Exit", "Выход"),
    "back": ("Back", "Назад"),
    "title1": ("BUTTON", "КНОПКА"),
    "title2": ("AND GUN", "И ПИСТОЛЕТ"),
    "helpt": ("HOW TO PLAY", "КАК ИГРАТЬ"),
    "r1": ("Press the RED button only when GREEN is on.", "Жми КРАСНУЮ кнопку, только когда ЗЕЛЁНЫЙ."),
    "r2": ("Red or yellow light = false start: the gun goes to your opponent.", "Красный или жёлтый свет = фальстарт: пистолет уходит сопернику."),
    "r3": ("BLUE button = trap: pressing it gives the gun away.", "СИНЯЯ кнопка = подстава: нажал - отдал пистолет."),
    "r4": ("Got the gun? Tap your half to aim at yourself,", "Получил пистолет? Тап по своей половине - в себя,"),
    "r5": ("the opponent's half to aim at them. Tap again to fire.", "по половине соперника - в него. Ещё тап - выстрел."),
    "r6": ("3 lives. Each hit takes a hand; the last life is the head.", "3 жизни. Каждое попадание - рука; последняя жизнь - голова."),
    "r7": ("A miss while shooting yourself = JACKPOT: next shot is 100%.", "Осечка в себя = ДЖЕКПОТ: следующий выстрел 100%."),
    "wait": ("WAIT...", "ЖДИ..."),
    "getready": ("GET READY...", "ГОТОВЬСЯ..."),
    "go": ("GO!!!", "ЖМИ!!!"),
    "false": ("FALSE START!", "ФАЛЬСТАРТ!"),
    "trap": ("TRAP!", "ПОДСТАВА!"),
    "click": ("CLICK...", "ЩЁЛК..."),
    "hit": ("HIT!", "ПОПАЛ!"),
    "minus": ("-1 LIFE", "-1 ЖИЗНЬ"),
    "selfhurt": ("HE HURT HIMSELF!", "ОН РАНИЛ СЕБЯ!"),
    "win": ("WIN!", "ПОБЕДА!"),
    "lose": ("DEFEAT", "ПОРАЖЕНИЕ"),
    "jackpot": ("JACKPOT!", "ДЖЕКПОТ!"),
    "jackpot_tap": ("TAP - 100% shot!", "ТАП - выстрел 100%!"),
    "jackpot_foe": ("OPPONENT HAS JACKPOT!", "ДЖЕКПОТ У СОПЕРНИКА!"),
    "choose": ("CHOOSE TARGET - TAP", "ВЫБЕРИ ЦЕЛЬ - ТАП"),
    "tapagain": ("TAP AGAIN - FIRE!", "ЕЩЁ ТАП - ВЫСТРЕЛ!"),
    "to_foe": ("AT OPPONENT", "В СОПЕРНИКА"),
    "to_self_head": ("AT MYSELF - head!", "В СЕБЯ - в голову!"),
    "to_self_arm": ("AT MYSELF - arm", "В СЕБЯ - в руку"),
    "foe_choose": ("Opponent is choosing...", "Соперник выбирает цель..."),
    "foe_mistake": ("OPPONENT ERRED!", "СОПЕРНИК ОШИБСЯ!"),
    "faster": ("YOU WERE FASTER!", "ТЫ БЫСТРЕЕ!"),
    "left_hand": ("Taking the gun with your left hand", "Берёшь пистолет левой рукой"),
    "head_grip": ("Both hands hurt - taking it with your head!", "Обе руки ранены - берёшь головой!"),
    "again": ("Play again", "Ещё раз"),
    "menu": ("Menu", "В меню"),
    "bot": ("Bot", "Бот"),
    "opponent": ("Opponent", "Соперник"),
    "player": ("Player", "Игрок"),
    "find": ("Find a room", "Найти комнату"),
    "nomodule": ("Module paho-mqtt is not installed", "Не установлен модуль paho-mqtt"),
    "r8": ("Online: 'Find a room' joins any open room, 'Create my room' waits for a player.", "Онлайн: «Найти комнату» входит в любую открытую комнату, «Создать» ждёт игрока."),
    "lobby_title": ("ROOM SEARCH", "ПОИСК КОМНАТЫ"),
    "create": ("Create my room", "Создать свою комнату"),
    "vs_bot": ("Play vs bot", "Играть с ботом"),
    "searching": ("Searching for a room...", "Ищем комнату..."),
    "waiting": ("Room created. Waiting for an opponent...", "Комната создана. Ждём соперника..."),
    "noserver": ("No internet connection", "Нет интернета"),
    "noroom": ("No open rooms right now", "Открытых комнат сейчас нет"),
    "waiting_host": ("Waiting for the opponent...", "Ждём соперника..."),
    "joining": ("Joining the room...", "Подключаемся к комнате..."),
    "settings": ("Settings", "Настройки"),
    "music": ("Music", "Музыка"),
    "sound": ("Sound", "Звук"),
    "revenge": ("Revenge", "Реванш"),
    "join_any": ("Join a room", "Подключиться к комнате"),
    "join_code": ("Join by code", "Подключиться по коду"),
    "connect": ("Connect", "Подключиться"),
    "nocode": ("Room not found", "Комната не найдена"),
    "badcode": ("Wrong code format", "Неверный формат кода"),
    "enter_code": ("Enter room code", "Введите код комнаты"),
    "room_lbl": ("Room", "Комната"),
    "opp_left": ("Opponent left the match", "Соперник вышел из матча"),
    "leave_q": ("Leave the match?", "Выйти из матча?"),
    "yes": ("Yes", "Да"),
    "no": ("No", "Нет"),
    "waiting_guest": ("Connected. Waiting for the host...", "Подключились. Ждём начала..."),
    "cancel": ("Cancel", "Отмена"),
    "bye": ("Opponent left the game", "Соперник вышел из игры"),
    "paired": ("Opponent found!", "Соперник найден!"),
}


def tr(key):
    en, ru = T[key]
    return en if LANG == "en" else ru
MENU_X = 6.0 * v                          # кнопки меню - левая колонка
BTN_PLAY = (MENU_X, CY - 3.0 * v, 8.6 * v, 2.4 * v)   # главное меню: (центр x, центр y, ширина, высота)
BTN_HELP = (MENU_X, CY, 8.6 * v, 2.4 * v)
BTN_EXIT = (MENU_X, CY + 3.0 * v, 8.6 * v, 2.4 * v)
BTN_BACK = (MENU_X, CY + 3.0 * v, 10.5 * v, 3.0 * v)     # кнопка Cancel на экране ожидания
BTN_FIND = (MENU_X, CY - 4.35 * v, 10.5 * v, 2.6 * v)    # поиск комнаты: четыре кнопки
BTN_CREATE = (MENU_X, CY - 1.45 * v, 10.5 * v, 2.6 * v)
BTN_VSBOT = (MENU_X, CY + 1.45 * v, 10.5 * v, 2.6 * v)
BTN_LBACK = (MENU_X, CY + 4.35 * v, 10.5 * v, 2.6 * v)
BTN_HBACK = (CX, H - 2.6 * v, 9.2 * v, 2.2 * v)         # Help: кнопка Back под текстом
SLD_MUSIC = (CX, CY - 1.6 * v, 9.0 * v, 0.9 * v)         # ползунок музыки (центр x, центр y, ширина, высота)
SLD_SFX = (CX, CY + 0.4 * v, 9.0 * v, 0.9 * v)           # ползунок звука
BTN_SHELP = (CX, CY + 2.6 * v, 10.5 * v, 2.6 * v)        # в настройках: Help
BTN_SBACK = (CX, CY + 5.0 * v, 10.5 * v, 2.6 * v)        # в настройках: Back
FIELD_RECT = (MENU_X, CY - 3.4 * v, 10.5 * v, 2.6 * v)   # поле ввода кода комнаты
BTN_CONNECT = (MENU_X, CY - 0.6 * v, 10.5 * v, 2.5 * v)   # кнопка Connect под полем
BTN_CANCEL = (CX, CY + 2.6 * v, 10.5 * v, 2.6 * v)      # Cancel под текстом ожидания
BTN_BACKGAME = (2.4 * v, 1.1 * v, 3.2 * v, 1.4 * v)     # маленькая Back в углу игры
BTN_YES = (CX - 2.8 * v, CY + 1.2 * v, 4.8 * v, 2.4 * v)
BTN_NO = (CX + 2.8 * v, CY + 1.2 * v, 4.8 * v, 2.4 * v)
BTN_AGAIN = (CX, CY - 0.6 * v, 10.5 * v, 2.6 * v)   # после матча - в центре
BTN_MENU = (CX, CY + 2.4 * v, 10.5 * v, 2.6 * v)
BTN_LANG = (W - 2.7 * v, 1.3 * v, 3.8 * v, 1.9 * v)          # EN / RU - только в главном меню
TITLE_X = W * 0.72                           # заголовок между серединой и правым краем
SKIN = (228, 184, 144)


# ----------------------------------------------------------------- утилиты
def clamp01(x):
    return max(0.0, min(1.0, x))


def ease(x):
    x = clamp01(x)
    return x * x * (3 - 2 * x)


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_ang(a, b, t):
    d = (b - a + math.pi) % math.tau - math.pi
    return a + d * t


def lerp_pt(a, b, t):
    return (lerp(a[0], b[0], t), lerp(a[1], b[1], t))


def mix(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def P(i, dist, dx=0.0):
    """Точка на расстоянии dist от края игрока i (к центру)."""
    return (CX + dx, EDGE[i] + INW[i] * (dist + SEAT))


def side_pos(i, off):
    """Позиция текста для игрока i: off от центра в сторону игрока."""
    off = min(2.9, max(1.6, 2.2 + 0.5 * (off - 3.0)))      # подписи ближе к центру, не на кругах
    return (CX, CY - INW[i] * off * v)


# ----------------------------------------------------------------- шрифты
_here = os.path.dirname(os.path.abspath(__file__))
# как в Pydroid: сначала системный Roboto (обычный, не жирный), иначе свой font.ttf
_font_path = None
for _cand in ("/system/fonts/Roboto-Regular.ttf", "/system/fonts/NotoSans-Regular.ttf",
              "/system/fonts/DroidSans.ttf", os.path.join(_here, "font.ttf")):
    if os.path.exists(_cand):
        _font_path = _cand
        break
if _font_path is None:
    try:
        _font_path = pygame.font.match_font("roboto,dejavusans,arial,notosans,freesans")
    except Exception:
        _font_path = None
_fonts = {}


def font(size):
    size = max(8, int(size))
    if size not in _fonts:
        _fonts[size] = pygame.font.Font(_font_path, size)
    return _fonts[size]


def _num(x):
    return x if isinstance(x, (int, float)) else None


def text(surf, s, size, color, center, side=0, alpha=255):
    """side=1 - текст перевёрнут на 180° (для верхнего игрока).
    Слишком длинный текст уменьшается, а центр сдвигается, чтобы не вылезать за края экрана."""
    f = font(size)
    img = f.render(s, True, color)
    w = _num(img.get_width())
    if w is not None and size > 8:
        # центр не двигаем; уменьшаем шрифт, только если текст не влезает от центра до края
        room = 2 * min(center[0], W - center[0]) - 12
        limit = min(room, W * 0.94)
        if w > limit:
            size = max(8, int(size * limit / w))
            f = font(size)
            img = f.render(s, True, color)
    sh = f.render(s, True, (0, 0, 0))
    base = pygame.Surface((img.get_width() + 4, img.get_height() + 4), pygame.SRCALPHA)
    base.blit(sh, (3, 3))
    base.blit(img, (0, 0))
    if side == 1:
        base = pygame.transform.rotate(base, 180)
    if alpha < 255:
        base.set_alpha(int(alpha))
    surf.blit(base, base.get_rect(center=(int(center[0]), int(center[1]))))


# ----------------------------------------------------------------- графика
def make_table():
    s = pygame.Surface((W, H))
    plank = max(6, int(1.5 * v))
    rnd = random.Random(7)
    y = 0
    while y < H:
        shade = rnd.randint(-8, 8)
        base = (86 + shade, 58 + shade, 36 + shade)
        pygame.draw.rect(s, base, (0, y, W, plank))
        for _ in range(14):
            gy = y + rnd.randint(2, plank - 2)
            gx = rnd.randint(0, W)
            pygame.draw.line(s, (base[0] - 14, base[1] - 10, base[2] - 8),
                             (gx, gy), (gx + rnd.randint(W // 8, W // 3), gy), 1)
        pygame.draw.line(s, (40, 26, 16), (0, y), (W, y), 2)
        y += plank
    pygame.draw.circle(s, (24, 70, 52), (int(CX), int(CY)), int(3.6 * v))
    pygame.draw.circle(s, (14, 44, 32), (int(CX), int(CY)), int(3.6 * v), 4)
    return s


def make_vignette(color):
    n = 80
    small = pygame.Surface((n, n), pygame.SRCALPHA)
    for yy in range(n):
        for xx in range(n):
            dx = (xx / (n - 1.0) - 0.5) * 2
            dy = (yy / (n - 1.0) - 0.5) * 2
            d = math.sqrt(dx * dx + dy * dy) / 1.414
            a = int(255 * (clamp01((d - 0.3) / 0.7) ** 1.5))
            small.set_at((xx, yy), (color[0], color[1], color[2], a))
    return pygame.transform.smoothscale(small, (W, H))


_glow = {}


def glow(color, r):
    key = (color, int(r))
    if key not in _glow:
        n = max(4, int(r * 2))
        s = pygame.Surface((n, n), pygame.SRCALPHA)
        for k in range(12, 0, -1):
            rr = max(1, int(r * k / 12.0))
            pygame.draw.circle(s, (color[0], color[1], color[2], 8 + (12 - k) * 14),
                               (n // 2, n // 2), rr)
        _glow[key] = s
    return _glow[key]


def draw_light(cv, phase):
    """Светофор горизонтально в правом верхнем углу: красный - жёлтый - зелёный слева направо."""
    bw, bh = 5.6 * v, 2.2 * v
    cx, cy = W - 6.4 * v, 1.55 * v
    rect = pygame.Rect(0, 0, int(bw), int(bh))
    rect.center = (int(cx), int(cy))
    pygame.draw.rect(cv, (18, 18, 20), rect, border_radius=int(0.5 * v))
    pygame.draw.rect(cv, (80, 80, 88), rect, 3, border_radius=int(0.5 * v))
    for name, col, off in (("red", RED, -1.8), ("yellow", YEL, 0.0), ("green", GRN, 1.8)):
        c = (int(cx + off * v), int(cy))
        on = (name == phase)
        if on:
            g = glow(col, 2.6 * v)
            cv.blit(g, g.get_rect(center=c))
        pygame.draw.circle(cv, col if on else mix(col, (18, 18, 20), 0.82), c, int(0.65 * v))


def draw_button(cv, alpha, scale, press, blue=False):
    if alpha <= 0.01:
        return
    R = int(2.0 * v)
    size = R * 2
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    c = (R, R)
    pygame.draw.circle(surf, (35, 35, 40), c, int(1.85 * v))
    pygame.draw.circle(surf, (115, 117, 125), c, int(1.7 * v))
    pygame.draw.circle(surf, (60, 60, 66), c, int(1.5 * v))
    top_r = int(1.32 * v * (1 - 0.1 * press))
    base = (45, 110, 240) if blue else (235, 45, 45)
    dk = (20, 55, 150) if blue else (150, 20, 20)
    col = mix(base, dk, press)
    pygame.draw.circle(surf, mix(col, (0, 0, 0), 0.4), c, top_r + int(0.12 * v))
    pygame.draw.circle(surf, col, (c[0], c[1] - int(0.1 * v * (1 - press))), top_r)
    pygame.draw.circle(surf, mix(col, (255, 255, 255), 0.5),
                       (c[0] - int(0.4 * v), c[1] - int(0.5 * v)), max(2, int(0.3 * v)))
    nz = max(4, int(size * scale * BTN))
    surf = pygame.transform.smoothscale(surf, (nz, nz))
    surf.set_alpha(int(255 * clamp01(alpha)))
    cv.blit(surf, surf.get_rect(center=(int(CX), int(CY))))


# ----------------------------------------------------------------- пистолет
GW, GH = int(3.5 * v), int(1.6 * v)
GRIP = (0.9 * v, 0.45 * v)
MUZ = (3.4 * v, 0.45 * v)


def make_gun():
    s = pygame.Surface((GW, GH), pygame.SRCALPHA)
    pygame.draw.polygon(s, (50, 34, 26), [(0.55 * v, 0.55 * v), (1.5 * v, 0.55 * v),
                                          (1.3 * v, 1.55 * v), (0.4 * v, 1.55 * v)])
    pygame.draw.rect(s, (70, 72, 82), (0.45 * v, 0.1 * v, 2.95 * v, 0.7 * v), border_radius=int(0.18 * v))
    pygame.draw.rect(s, (25, 25, 30), (0.45 * v, 0.1 * v, 2.95 * v, 0.7 * v), 2, border_radius=int(0.18 * v))
    pygame.draw.line(s, (150, 155, 168), (0.7 * v, 0.24 * v), (3.2 * v, 0.24 * v), 2)
    pygame.draw.rect(s, (25, 25, 30), (1.55 * v, 0.8 * v, 0.6 * v, 0.4 * v), 3)
    pygame.draw.circle(s, (15, 15, 18), (int(3.38 * v), int(0.45 * v)), max(2, int(0.1 * v)))
    return s


GUN_BASE = make_gun()


def gun_axes(a):
    return (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))


def draw_gun(cv, pos, a, scale=1.0, alpha=255):
    if alpha <= 2:
        return
    img = GUN_BASE
    if abs(scale - 1) > 0.001:
        img = pygame.transform.smoothscale(img, (max(4, int(GW * scale)), max(4, int(GH * scale))))
    w, h = img.get_size()
    gx, gy = GRIP[0] * scale, GRIP[1] * scale
    ox, oy = w / 2.0 - gx, h / 2.0 - gy
    ex, ey = gun_axes(a)
    cx = pos[0] + ox * ex[0] + oy * ey[0]
    cy = pos[1] + ox * ex[1] + oy * ey[1]
    rot = pygame.transform.rotate(img, -math.degrees(a))
    if alpha < 255:
        rot.set_alpha(int(alpha))
    cv.blit(rot, rot.get_rect(center=(int(cx), int(cy))))


def muzzle(pos, a, scale=1.0):
    mx = (MUZ[0] - GRIP[0]) * scale
    my = (MUZ[1] - GRIP[1]) * scale
    ex, ey = gun_axes(a)
    return (pos[0] + mx * ex[0] + my * ey[0], pos[1] + mx * ex[1] + my * ey[1])


# ----------------------------------------------------------------- игрок
def ui_button(sc, cx, cy, w, h, label, color):
    rect = pygame.Rect(0, 0, int(w), int(h))
    rect.center = (int(cx), int(cy))
    pygame.draw.rect(sc, color, rect, border_radius=int(0.5 * v))
    pygame.draw.rect(sc, mix(color, (255, 255, 255), 0.45), rect, 3, border_radius=int(0.5 * v))
    text(sc, label, min(h * 0.55, w * 1.45 / max(1, len(label))), (255, 255, 255), (cx, cy))


def hit(x, y, b):
    return x is not None and y is not None and abs(x - b[0]) <= b[2] / 2 and abs(y - b[1]) <= b[3] / 2


def draw_heart(cv, cx, cy, r, color):
    pygame.draw.circle(cv, color, (int(cx - r * 0.5), int(cy - r * 0.3)), int(r * 0.58))
    pygame.draw.circle(cv, color, (int(cx + r * 0.5), int(cy - r * 0.3)), int(r * 0.58))
    pygame.draw.polygon(cv, color, [(cx - r * 1.02, cy - r * 0.05), (cx + r * 1.02, cy - r * 0.05), (cx, cy + r * 1.05)])


def shadow_ellipse(cv, cx, cy, w, h, a=70):
    sf = pygame.Surface((max(2, int(w)), max(2, int(h))), pygame.SRCALPHA)
    pygame.draw.ellipse(sf, (0, 0, 0, a), sf.get_rect())
    cv.blit(sf, sf.get_rect(center=(int(cx), int(cy))))


def draw_player(cv, i, po):
    """Человечек - круг с глазками. Чем больше ран, тем заметнее лёгкая дрожь (при полном здоровье дрожи нет).
    Испуг (джекпот у соперника): огромные глаза и открытый рот."""
    if po["hidden"]:
        return
    col = PCOL[i]
    dark = mix(col, (0, 0, 0), 0.45)
    light = mix(col, (255, 255, 255), 0.3)
    look, closed, squint, ux, uy, wide = po["eye"]
    scared = wide > 0.3
    tt = po["t"]
    wounds = max(0, 3 - po["lives"])            # 0 - полное здоровье, без дрожи
    amp = (wounds * 0.007 + (0.012 if scared else 0.0)) * v
    jx = math.sin(tt * 29 + i) * amp
    jy = math.cos(tt * 23 + i) * amp
    cc0 = P(i, BODY_D * v + po["off"], po["dx"])
    cc = (cc0[0] + jx, cc0[1] + jy)
    R = 1.9 * v
    rect = pygame.Rect(0, 0, int(R * 2), int(R * 2))
    rect.center = (int(cc[0]), int(cc[1]))
    pygame.draw.ellipse(cv, dark, rect)
    pygame.draw.ellipse(cv, col, rect.inflate(-int(0.3 * v), -int(0.3 * v)))
    # взгляд
    bx, by = 0.0, float(INW[i])
    gx, gy = bx * 0.5 + (ux * 0.95 - bx * 0.5) * look, by * 0.5 + (uy * 0.95 - by * 0.5) * look
    gl = math.hypot(gx, gy) or 1.0
    px, py = -gy / gl, gx / gl
    ecx, ecy = cc[0] + gx * v, cc[1] + gy * v
    EYE = (20, 20, 25)
    r = 0.17 * v
    for sgn in (-1, 1):
        ex, ey = ecx + sgn * px * 0.55 * v, ecy + sgn * py * 0.55 * v
        if closed >= 0.45:                      # зажмурился: > <
            a = 0.24 * v
            tx, ty = -sgn * px, -sgn * py
            nx, ny = gx / gl, gy / gl
            pts = [(ex - tx * a + nx * a, ey - ty * a + ny * a),
                   (ex + tx * a * 0.3, ey + ty * a * 0.3),
                   (ex - tx * a - nx * a, ey - ty * a - ny * a)]
            pygame.draw.lines(cv, EYE, False, pts, max(3, int(0.12 * v)))
        else:
            hf = max(0.15, (1 - 0.65 * squint) * (1 - closed * 1.5))
            er = pygame.Rect(0, 0, int(r * (2 + 0.6 * squint)), max(2, int(r * 2 * hf)))
            er.center = (int(ex), int(ey))
            pygame.draw.ellipse(cv, EYE, er)
    if scared and closed >= 0.45:               # при джекпоте: чёрная полоска поверх закрытых глаз
        ax, ay = ecx - px * 0.55 * v, ecy - py * 0.55 * v
        bx2, by2 = ecx + px * 0.55 * v, ecy + py * 0.55 * v
        pygame.draw.line(cv, (10, 10, 12), (int(ax), int(ay)), (int(bx2), int(by2)), max(3, int(0.42 * v)))
    if scared:                                  # испуг: открытый рот "O"
        mx, my = cc[0], cc[1] + INW[i] * 1.05 * v
        pygame.draw.ellipse(cv, EYE, pygame.Rect(int(mx - 0.2 * v), int(my - 0.28 * v), int(0.4 * v), int(0.56 * v)))
    # кисти - отдельные кружки
    for hp in po["hands"]:
        if hp is None:
            continue
        pygame.draw.circle(cv, dark, (int(hp[0]), int(hp[1])), int(0.5 * v))
        pygame.draw.circle(cv, light, (int(hp[0]), int(hp[1])), int(0.4 * v))


# ----------------------------------------------------------------- игра
def fl(i):
    """Переворачивать текст на 180°, если игрок сидит сверху."""
    return 1 if INW[i] == 1 else 0


def mine(i):
    """Показываем только свои тексты."""
    return LOCAL_PLAYER is None or LOCAL_PLAYER == i


def hit_slider(x, y, rect):
    cx, cy, w, h = rect
    return x is not None and y is not None and abs(x - cx) <= w / 2 + 0.5 * v and abs(y - cy) <= h * 2


def slider_value(x, rect):
    cx, cy, w, h = rect
    return max(0.0, min(1.0, (x - (cx - w / 2)) / w))


def draw_slider(sc, rect, label, val):
    cx, cy, w, h = rect
    left = cx - w / 2
    pygame.draw.rect(sc, (60, 60, 70), pygame.Rect(int(left), int(cy - h / 2), int(w), int(h)),
                     border_radius=int(h / 2))
    if val > 0:
        pygame.draw.rect(sc, (120, 200, 120), pygame.Rect(int(left), int(cy - h / 2), int(w * val), int(h)),
                         border_radius=int(h / 2))
    pygame.draw.circle(sc, (240, 240, 240), (int(left + w * val), int(cy)), int(h * 0.9))
    text(sc, f"{label}: {int(val * 100)}%", v * 0.7, (255, 255, 255), (cx, cy - 1.0 * v))


def set_mode(online):
    """online=True - матч через сервер, иначе - игра с ботом."""
    global VS_BOT, ONLINE
    ONLINE = bool(online)
    VS_BOT = not ONLINE


SND = {}
_HERE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))   # папка с файлами (и внутри exe)


def load_sounds():
    """Загружает звуки выстрела и щелчка. Если звука нет - игра работает без него."""
    try:
        SND["shot"] = pygame.mixer.Sound(os.path.join(_HERE, "shot.mp3"))
        SND["click"] = pygame.mixer.Sound(os.path.join(_HERE, "click.mp3"))
        set_sfx_vol(SFX_VOL)
    except Exception:
        SND.clear()


MUSIC_VOL = 0.35
SFX_VOL = 1.0
MUS = {"cur": None, "base": 0.0, "resume": 0.0}


def set_music_vol(x):
    global MUSIC_VOL
    MUSIC_VOL = max(0.0, min(1.0, x))
    try:
        pygame.mixer.music.set_volume(MUSIC_VOL)
    except Exception:
        pass


def set_sfx_vol(x):
    global SFX_VOL
    SFX_VOL = max(0.0, min(1.0, x))
    for snd in SND.values():
        try:
            snd.set_volume(SFX_VOL)
        except Exception:
            pass


def _mus_load(name, start=0.0):
    try:
        pygame.mixer.music.load(os.path.join(_HERE, name))
        pygame.mixer.music.set_volume(MUSIC_VOL)
        try:
            pygame.mixer.music.play(-1, start)
        except Exception:
            pygame.mixer.music.play(-1)
    except Exception:
        pass


def music_gun_on():
    """Взял пистолет: играет другая музыка, фоновая запоминает место."""
    if MUS["cur"] != "bg":
        return
    try:
        pos = MUS["base"] + max(0, pygame.mixer.music.get_pos()) / 1000.0
    except Exception:
        pos = MUS["base"]
    MUS["resume"] = pos
    MUS["cur"] = "gun"
    _mus_load("gun_music.mp3")


def music_bg_on():
    """Выстрел или щелчок: снова фоновая музыка с того места, где оборвалась."""
    if MUS["cur"] != "gun":
        return
    MUS["cur"] = "bg"
    MUS["base"] = MUS["resume"]
    _mus_load("music.mp3", MUS["resume"])


def play_sfx(name):
    snd = SND.get(name)
    if snd is not None:
        try:
            snd.play()
        except Exception:
            pass


def play_music():
    """Фоновая музыка - играет всё время, и в меню, и в игре."""
    MUS["cur"] = "bg"
    MUS["base"] = 0.0
    _mus_load("music.mp3")


NET_Q = queue.Queue()                       # сообщения сети для игры
REMOTE_LAG = 0.35                            # допуск на задержку интернета для нажатий соперника
MQTT_HOST = "broker.hivemq.com"              # публичный бесплатный брокер MQTT, без регистрации
MQTT_PORT = 1883
MQTT_TOPIC = "buttonandgun/v1"               # префикс топиков игры
ROOM_FRESH = 120.0                           # комната без обновления дольше этого времени мёртвая
SEARCH_TIMEOUT = 30.0                        # сек поиска до "Открытых комнат нет"
HB_EVERY = 3.0                               # пульс связи, сек
HB_TIMEOUT = 15.0                            # сек без вестей - соперник пропал


def _enc_str(t):
    b = t.encode("utf-8")
    return len(b).to_bytes(2, "big") + b


def _enc_len(n):
    out = bytearray()
    while True:
        d = n % 128
        n //= 128
        if n:
            d |= 0x80
        out.append(d)
        if not n:
            return bytes(out)


def new_room_code():
    d = "0123456789"
    l = string.ascii_uppercase
    return "R" + random.choice(d) + random.choice(l) + random.choice(d) + random.choice(l)


def valid_room_code(c):
    return len(c) == 5 and c[0] == "R" and c[1].isdigit() and c[2].isupper() and c[3].isdigit() and c[4].isupper()


class MqttConn:
    """Минимальный клиент MQTT 3.1.1 на стандартной библиотеке (QoS 0, без TLS).
    Не нужны никакие внешние пакеты, поэтому работает и в APK."""

    def __init__(s, on_publish, on_close):
        s.sock = None
        s.alive = False
        s.pid = 0
        s.wlock = threading.Lock()
        s.on_publish = on_publish
        s.on_close = on_close

    def _read_exact(s, n):
        buf = b""
        while len(buf) < n:
            chunk = s.sock.recv(n - len(buf))
            if not chunk:
                raise OSError("connection closed")
            buf += chunk
        return buf

    def _write(s, data):
        with s.wlock:
            s.sock.sendall(data)

    def connect(s, client_id):
        s.sock = socket.create_connection((MQTT_HOST, MQTT_PORT), timeout=8)
        s.sock.settimeout(None)
        var = _enc_str("MQTT") + bytes([4, 0x02]) + (60).to_bytes(2, "big")
        body = var + _enc_str(client_id)
        s._write(bytes([0x10]) + _enc_len(len(body)) + body)
        ack = s._read_exact(4)
        if ack[0] != 0x20 or ack[3] != 0:
            raise OSError("MQTT refused")
        s.alive = True
        threading.Thread(target=s._reader, daemon=True).start()
        threading.Thread(target=s._pinger, daemon=True).start()

    def _reader(s):
        try:
            while s.alive:
                b0 = s._read_exact(1)[0]
                mult, rem = 1, 0
                while True:
                    d = s._read_exact(1)[0]
                    rem += (d & 0x7F) * mult
                    mult *= 128
                    if not d & 0x80:
                        break
                body = s._read_exact(rem) if rem else b""
                if b0 & 0xF0 == 0x30:                        # PUBLISH
                    tl = int.from_bytes(body[:2], "big")
                    s.on_publish(body[2:2 + tl].decode("utf-8"), body[2 + tl:])
        except Exception:
            pass
        was = s.alive
        s.alive = False
        if was:
            s.on_close()

    def _pinger(s):
        while s.alive:
            time.sleep(30)
            try:
                s._write(bytes([0xC0, 0]))
            except OSError:
                return

    def subscribe(s, topic):
        s.pid = s.pid % 65535 + 1
        body = s.pid.to_bytes(2, "big") + _enc_str(topic) + bytes([0])
        s._write(bytes([0x82]) + _enc_len(len(body)) + body)

    def publish(s, topic, payload, retain=False):
        body = _enc_str(topic) + payload
        s._write(bytes([0x31 if retain else 0x30]) + _enc_len(len(body)) + body)

    def disconnect(s):
        try:
            s._write(bytes([0xE0, 0]))
        except OSError:
            pass
        s.alive = False
        try:
            s.sock.close()
        except Exception:
            pass


class Net:
    """Комнаты через публичный брокер MQTT. Хост публикует комнату (retained), гость находит
    её в списке и отправляет запрос на вход. Ходы идут через топики /h (от гостя) и /g (от хоста)."""

    def __init__(s):
        s.session = 0
        s.conn = None
        s.role = None
        s.room = None
        s.paired = False
        s.found = {}
        s.ack = threading.Event()
        s.last_rx = time.time()
        s.error = "noserver"

    def _put(s, g, msg):
        if g == s.session:
            msg["_s"] = g
            NET_Q.put(msg)

    def _open(s, g):
        conn = MqttConn(lambda t, p: s._on_msg(g, t, p),
                        lambda: s._put(g, {"k": "sys", "e": "closed"}))
        conn.connect("bng" + os.urandom(6).hex())
        s.conn = conn
        s.paired = False
        s.found = {}
        s.ack = threading.Event()
        s.last_rx = time.time()

    def _on_msg(s, g, topic, payload):
        if g != s.session:
            return
        if topic.startswith(MQTT_TOPIC + "/rooms/"):
            if payload:
                s.found[topic] = payload
            else:
                s.found.pop(topic, None)
            return
        try:
            m = json.loads(payload.decode("utf-8"))
        except ValueError:
            return
        s.last_rx = time.time()
        if m.get("k") == "hb":
            return
        if s.role == "host":
            if topic.endswith("/join"):
                if not s.paired:
                    s.paired = True
                    s.conn.publish(f"{MQTT_TOPIC}/rooms/{s.room}", b"", retain=True)  # комната занята
                    s.conn.publish(f"{MQTT_TOPIC}/room/{s.room}/g",
                                   json.dumps({"k": "sys", "e": "paired"}).encode("utf-8"))
                    s._put(g, {"k": "sys", "e": "paired", "role": "host"})
                    threading.Thread(target=s._heartbeat, args=(g,), daemon=True).start()
            elif topic.endswith("/h"):
                s._put(g, m)
        elif s.role == "guest" and topic.endswith("/g"):
            if m.get("k") == "sys" and m.get("e") == "paired":
                if not s.paired:
                    s.paired = True
                    s.ack.set()
                    s._put(g, {"k": "sys", "e": "paired", "role": "guest"})
            else:
                s._put(g, m)

    def _announce(s):
        s.conn.publish(f"{MQTT_TOPIC}/rooms/{s.room}",
                       json.dumps({"id": s.room, "t": time.time()}).encode("utf-8"), retain=True)

    def _refresh(s, g):
        while g == s.session and not s.paired and s.conn is not None:
            time.sleep(25)
            try:
                if g == s.session and not s.paired and s.conn is not None:
                    s._announce()
            except OSError:
                return

    def _heartbeat(s, g):
        while g == s.session and s.paired:
            time.sleep(HB_EVERY)
            out = "g" if s.role == "host" else "h"
            try:
                if g == s.session and s.conn is not None:
                    s.conn.publish(f"{MQTT_TOPIC}/room/{s.room}/{out}", b'{"k":"hb"}')
            except OSError:
                return
            if g == s.session and time.time() - s.last_rx > HB_TIMEOUT:
                s._put(g, {"k": "sys", "e": "closed"})
                return

    def close(s):
        s.session += 1
        conn = s.conn
        s.conn = None
        if conn is not None:
            try:
                if s.room and s.role == "host" and not s.paired:
                    conn.publish(f"{MQTT_TOPIC}/rooms/{s.room}", b"", retain=True)
                if s.room and s.paired:
                    out = "g" if s.role == "host" else "h"
                    conn.publish(f"{MQTT_TOPIC}/room/{s.room}/{out}",
                                 json.dumps({"k": "sys", "e": "bye"}).encode("utf-8"))
            except OSError:
                pass
            conn.disconnect()
        s.role = None
        s.room = None
        s.paired = False

    def host(s):
        """Создать комнату. False - если нет связи с брокером (s.error объясняет почему)."""
        s.close()
        g = s.session
        try:
            s._open(g)
            s.role = "host"
            s.room = new_room_code()
            s.conn.subscribe(f"{MQTT_TOPIC}/room/{s.room}/join")
            s.conn.subscribe(f"{MQTT_TOPIC}/room/{s.room}/h")
            s._announce()
        except OSError:
            s.error = "noserver"
            s.close()
            return False
        threading.Thread(target=s._refresh, args=(g,), daemon=True).start()
        return True

    def join_code(s, code):
        """Войти в комнату по коду (проверяем, что она объявлена)."""
        s.close()
        g = s.session
        try:
            s._open(g)
        except OSError:
            s.error = "noserver"
            return False
        threading.Thread(target=s._join_code_loop, args=(g, code), daemon=True).start()
        return True

    def _join_code_loop(s, g, code):
        s.conn.subscribe(f"{MQTT_TOPIC}/rooms/{code}")
        time.sleep(2.0)
        if g != s.session:
            return
        if not s.found.get(f"{MQTT_TOPIC}/rooms/{code}"):
            s._put(g, {"k": "sys", "e": "nocode"})
            s.close()
            return
        s.role = "guest"
        s.room = code
        s.ack.clear()
        s.conn.subscribe(f"{MQTT_TOPIC}/room/{code}/g")
        s.conn.publish(f"{MQTT_TOPIC}/room/{code}/join", b"{}")
        if s.ack.wait(4.0):
            threading.Thread(target=s._heartbeat, args=(g,), daemon=True).start()
            return
        s._put(g, {"k": "sys", "e": "nocode"})
        s.close()

    def search(s):
        """Искать открытую комнату и войти в неё. Поиск идёт в фоне."""
        s.close()
        g = s.session
        try:
            s._open(g)
        except OSError:
            s.error = "noserver"
            return False
        threading.Thread(target=s._search_loop, args=(g,), daemon=True).start()
        return True

    def _search_loop(s, g):
        started = time.time()
        s.conn.subscribe(f"{MQTT_TOPIC}/rooms/#")
        while g == s.session:
            time.sleep(1.5)
            now = time.time()
            cands = []
            for p in list(s.found.values()):
                try:
                    info = json.loads(p.decode("utf-8"))
                except ValueError:
                    continue
                if now - info.get("t", 0) < ROOM_FRESH:
                    cands.append((info["t"], info["id"]))
            for _t, rid in sorted(cands):                    # сначала самые старые комнаты
                if g != s.session:
                    return
                s.ack.clear()
                s.role = "guest"
                s.room = rid
                s._put(g, {"k": "sys", "e": "joining"})
                s.conn.subscribe(f"{MQTT_TOPIC}/room/{rid}/g")
                s.conn.publish(f"{MQTT_TOPIC}/room/{rid}/join", b"{}")
                if s.ack.wait(4.0):
                    threading.Thread(target=s._heartbeat, args=(g,), daemon=True).start()
                    return
            if time.time() - started > SEARCH_TIMEOUT:
                s._put(g, {"k": "sys", "e": "noroom"})
                s.close()
                return
            s.found = {}
            s.conn.subscribe(f"{MQTT_TOPIC}/rooms/#")

    def send(s, msg):
        if s.conn is None or not s.paired:
            return
        out = "g" if s.role == "host" else "h"
        try:
            s.conn.publish(f"{MQTT_TOPIC}/room/{s.room}/{out}",
                           json.dumps(msg, ensure_ascii=False).encode("utf-8"))
        except OSError:
            s._put(s.session, {"k": "sys", "e": "closed"})


NET = Net()


class Game:
    def __init__(s):
        s.canvas = pygame.Surface((W, H))
        s.table = make_table()
        s.vig_red = make_vignette((130, 0, 0))
        s.dark = pygame.Surface((W, H))
        s.dark.fill((0, 0, 0))
        s.white = pygame.Surface((W, H))
        s.white.fill((255, 255, 255))
        s.t = 0.0
        s.lives = [3, 3]
        s.last_press = [-9, -9]
        s.btn_alpha = 1.0
        s.btn_press = 0.0
        s.state = "title"
        s.phase = None
        s.phase_t = 0.0
        s.phase_dur = 1.0
        s.phase_id = 0
        s.blue = False
        s.hist = []
        s.since = 0.0
        s.fs = None
        s.fs_msg = ""
        s.bot_phase_id = -1
        s.bot_plan = None
        s.eye = [[0.0, 0.0, 0.0, 0.0, float(INW[0]), 0.0], [0.0, 0.0, 0.0, 0.0, float(INW[1]), 0.0]]
        s.net = None                    # None / 'host' (ведёт матч) / 'guest'
        s.netobj = None
        s.lobby_status = ""
        s.leave_ask = False
        s.left_msg = False
        s.my_rev = False
        s.foe_rev = False
        s.rev_dead = False
        s.drag = None
        s.code_text = "R"
        s.code_err = ""
        s.reset_gun_vars()

    def reset_gun_vars(s):
        s.gp = "take"            # take -> choose -> aim -> result -> (return | jackpot)
        s.pt = 0.0               # время внутри текущей стадии
        s.gun_t = 0.0
        s.holder = 0
        s.opp = 1
        s.sel = None             # выбранная (ещё не подтверждённая) цель: "opp" / "self"
        s.target = None          # подтверждённая цель
        s.aim_k = 0.0            # 0 - целится в соперника, 1 - в себя
        s.ext = 0.0
        s.jackpot = False
        s.fired = False
        s.fatal = False
        s.victim = None
        s.part = "arm"
        s.lv_snap = None         # жизни на момент подтверждения выстрела
        s.hit_sign = 1           # какая рука: +1 правая (1-е ранение), -1 левая (2-е)
        s.hit_c = None
        s.death_side = 1
        s.grip = "both"          # чем берёт пистолет: both - обе руки, left - одна рука, head - головой
        s.aim_dur = 2.0
        s.since_shot = 0.0
        s.smoke = []
        s.flash = 0.0
        s.shake = 0.0
        s.splat = []
        s.ret_from = None
        s.bot_gun = None
        s.tl = None

    # ---------- логика раундов
    def start_round(s):
        s.state = "light"
        s.phase = "red"
        s.phase_t = 0.0
        s.phase_dur = random.uniform(1.6, 3.6)
        s.fs = None
        s.blue = random.random() < 0.25
        s.phase_id += 1
        s.hist = []
        s.bot_plan = None
        s.since = s.t
        s.reset_gun_vars()
        s.emit_phase()

    def begin_gun(s, h):
        s.reset_gun_vars()
        s.state = "gun"
        music_gun_on()
        s.bot_plan = None
        s.holder = h
        s.opp = 1 - h
        lv = s.lives[h]                       # 3 жизни - две руки, 2 - одна рука, 1 - обе ранены
        s.grip = "both" if lv >= 3 else ("left" if lv == 2 else "head")
        s.btn_press = 1.0
        s.tl = s.timeline()

    def press(s, i, lag=0.08, y=None, x=None):
        global LANG
        if s.leave_ask:                                    # окно "Выйти из матча?"
            if hit(x, y, BTN_YES):
                s.leave_ask = False
                s.leave_to_menu()
            elif hit(x, y, BTN_NO):
                s.leave_ask = False
            return
        if s.state in ("light", "gun", "waiting") and hit(x, y, BTN_BACKGAME):
            s.leave_ask = True
            return
        if s.state == "title" and hit(x, y, BTN_LANG):      # кнопка языка - только в главном меню
            if s.t - s.last_press[i] < 0.3:
                return
            s.last_press[i] = s.t
            LANG = "ru" if LANG == "en" else "en"
            return
        if s.t - s.last_press[i] < 0.15:
            return
        s.last_press[i] = s.t
        if s.state == "title":
            if hit(x, y, BTN_PLAY):
                s.open_lobby()
            elif hit(x, y, BTN_HELP):
                s.state = "settings"
            elif hit(x, y, BTN_EXIT):
                quit_game()
        elif s.state == "settings":
            if hit_slider(x, y, SLD_MUSIC):
                s.drag = "music"
                set_music_vol(slider_value(x, SLD_MUSIC))
            elif hit_slider(x, y, SLD_SFX):
                s.drag = "sfx"
                set_sfx_vol(slider_value(x, SLD_SFX))
            elif hit(x, y, BTN_SHELP):
                s.state = "help"
            elif hit(x, y, BTN_SBACK):
                s.state = "title"
        elif s.state == "find":
            if hit(x, y, BTN_FIND):
                s.state = "lobby"
                s.lobby_find()
            elif hit(x, y, BTN_CREATE):
                s.state = "code"
                s.code_text = "R"
                s.code_err = ""
                pygame.key.start_text_input()
            elif hit(x, y, BTN_LBACK):
                s.state = "lobby"
        elif s.state == "code":
            if hit(x, y, BTN_CONNECT):
                s.try_code()
            elif hit(x, y, BTN_LBACK):
                pygame.key.stop_text_input()
                s.state = "find"
        elif s.state == "help":
            if hit(x, y, BTN_HBACK):
                s.state = "settings"
        elif s.state == "waiting":
            if hit(x, y, BTN_CANCEL):
                s.leave_to_menu()
        elif s.state == "lobby":
            if hit(x, y, BTN_FIND):
                s.state = "find"
            elif hit(x, y, BTN_CREATE):
                s.lobby_create()
            elif hit(x, y, BTN_VSBOT):
                s.lobby_bot()
            elif hit(x, y, BTN_LBACK):
                s.lobby_back()
        elif s.state == "light":
            if s.t - s.since < 0.4 or s.btn_alpha < 0.97:
                return
            if s.net == "guest":
                s.send({"k": "press"})
                return
            # судим по тому, что игрок ВИДЕЛ ~0.08 с назад (задержка пальца и экрана)
            ph, bl = s.phase, s.blue
            if lag > 0:
                for (tt, pp, bb) in s.hist:
                    if tt <= s.t - lag:
                        ph, bl = pp, bb
            if ph == "green" and not bl:
                s.fs = None
                s.begin_gun(i)
                s.emit_gun()
            else:
                s.fs = i                      # фальстарт / синяя кнопка - пистолет сопернику
                s.fs_msg = "trap" if bl else "false"
                s.begin_gun(1 - i)
                s.emit_gun()
        elif s.state == "gun":
            if i == s.holder and s.gp == "choose":
                s.choose_tap(y)
            elif i == s.holder and s.gp == "jackpot":
                s.jackpot_tap()
            elif s.gp == "result" and s.fatal and s.pt > 2.2:
                if hit(x, y, BTN_AGAIN) and not ONLINE:
                    s.lives = [3, 3]
                    s.start_round()
                elif hit(x, y, BTN_AGAIN) and ONLINE and s.net is not None and not s.rev_dead and not s.my_rev:
                    s.my_rev = True
                    s.send({"k": "rev"})
                    s.rev_check()
                elif hit(x, y, BTN_MENU):
                    s.leave_to_menu()

    def choose_tap(s, y):
        """Тап по своей половине - цель "в себя", по половине соперника - "в соперника".
        Первый тап выбирает цель, второй тап по той же цели - подтверждает выстрел."""
        if y is None or s.pt < 0.35:
            return
        bottom = 0 if INW[0] == -1 else 1
        zone = bottom if y >= H / 2 else 1 - bottom
        tgt = "self" if zone == s.holder else "opp"
        if s.net == "guest":
            c = 1 if s.sel == tgt else 0
            s.sel = tgt
            s.send({"k": "tap", "t": tgt, "c": c})
            return
        if s.sel == tgt:
            s.confirm(tgt)
        else:
            s.sel = tgt

    def confirm(s, tgt, aim=None):
        s.target = tgt
        s.sel = tgt
        s.victim = s.holder if tgt == "self" else s.opp
        s.lv_snap = list(s.lives)
        s.hit_sign = 1 if s.lv_snap[s.victim] >= 3 else -1
        s.part = "head" if s.lives[s.victim] <= 1 else "arm"
        s.gp = "aim"
        s.pt = 0.0
        s.bot_gun = None
        s.aim_dur = aim if aim is not None else (random.uniform(1.0, 1.4) if s.jackpot else random.uniform(1.6, 2.6))
        s.emit({"k": "conf", "t": tgt, "a": s.aim_dur})

    def resolve(s, forced=None):
        s.fired = s.jackpot or (random.random() < 0.5 if forced is None else bool(forced))
        play_sfx("shot" if s.fired else "click")
        music_bg_on()
        s.emit({"k": "res", "f": bool(s.fired)})
        s.gp = "result"
        s.pt = 0.0
        s.since_shot = 0.0
        if s.fired:
            s.hit_c = s.pose_target(s.target)[2]       # точка попадания (кисть или тело)
            s.fatal = s.lives[s.victim] <= 1
            s.lives[s.victim] -= 1
            s.flash = 1.0
            s.shake = 1.0
            if s.fatal:
                # тело разлетается на кровь и исчезает
                s.splat = [(random.uniform(0, math.tau), 1.0 + 5.5 * math.sqrt(random.random()),
                            random.uniform(0.1, 0.5), random.uniform(0.07, 0.18)) for _ in range(64)]
            else:
                # кисть разлетается на кровь и исчезает
                s.splat = [(random.uniform(0, math.tau), 0.5 + 2.4 * math.sqrt(random.random()),
                            random.uniform(0.08, 0.32), random.uniform(0.07, 0.16)) for _ in range(28)]

    def begin_return(s):
        s.ret_from = (s.tl["pos"], s.tl["a"], s.tl["scale"])
        s.gp = "return"
        s.pt = 0.0

    def begin_jackpot(s):
        s.jackpot = True
        s.gp = "jackpot"
        s.pt = 0.0
        s.sel = "opp"
        s.target = None
        s.lv_snap = None
        s.bot_gun = None

    # ---------- бот
    def bot_think(s):
        bot = 1 - LOCAL_PLAYER
        if s.phase_id != s.bot_phase_id:
            s.bot_phase_id = s.phase_id
            if s.phase == "green":
                if random.random() < 0.92:
                    s.bot_plan = s.t + random.uniform(*BOT_REACT)
            elif s.phase == "yellow":
                if random.random() < BOT_ANTICIPATE:
                    s.bot_plan = s.t + random.uniform(0.2, max(0.3, s.phase_dur - 0.1))
        if s.bot_plan is not None and s.t >= s.bot_plan:
            s.bot_plan = None
            if s.blue:
                go = random.random() > BOT_SEES_BLUE
            elif s.phase != "green":
                go = random.random() < BOT_COMMIT
            else:
                go = True
            if go:
                s.press(bot, lag=0)

    def bot_gun_think(s):
        """Бот с пистолетом: думает, выбирает цель, подтверждает."""
        if s.bot_gun is None:
            if s.gp == "jackpot":
                s.bot_gun = [s.t + random.uniform(0.5, 0.9), "opp", None]
            else:
                tgt = "opp"
                if s.lives[s.holder] > 1 and random.random() < BOT_SELF_PROB:
                    tgt = "self"
                s.bot_gun = [s.t + random.uniform(0.9, 1.8), tgt, None]
        plan = s.bot_gun
        if plan[2] is None and s.t >= plan[0]:
            if s.gp == "jackpot":
                s.confirm("opp")
                return
            s.sel = plan[1]
            plan[2] = s.t + random.uniform(0.5, 0.9)
        elif plan[2] is not None and s.t >= plan[2]:
            s.confirm(plan[1])

    # ---------- обновление
    def update(s, dt):
        s._update(dt)
        s.update_eyes(dt)

    def eye_goals(s, i):
        """Куда и как смотрит игрок: (взгляд, зажмурился, прищурился, испуг, направление).
        Напряжение нарастает: за ~1.2 с до выстрела - прищур, за 0.45 с - зажмуривание."""
        base = P(i, BODY_D * v)
        inward = (0.0, float(INW[i]))

        def toward(pt):
            dx, dy = pt[0] - base[0], pt[1] - base[1]
            d = math.hypot(dx, dy) or 1.0
            return (dx / d, dy / d)

        if s.state != "gun" or s.tl is None:
            return 0.0, 0.0, 0.0, 0.0, inward
        h, gp = s.holder, s.gp
        left = s.aim_dur - s.pt if gp == "aim" else 9.0     # сколько осталось до выстрела
        if i == h:
            if gp == "take":
                return 1.0, 0.0, 0.0, 0.0, toward(s.tl["pos"])
            if gp == "return":
                return 0.0, 0.0, 0.0, 0.0, inward
            if gp == "aim" and s.target == "self":
                T = s.pose_target("self")[2]
                if left < 0.45:
                    return 0.0, 1.0, 0.0, 0.0, inward         # зажмурился
                if left < 1.2:
                    return 1.0, 0.0, 1.0, 0.0, toward(T)      # прищурился
                return 1.0, 0.0, 0.0, 0.0, toward(T)
            if gp == "result" and s.target == "self" and s.pt < 0.7:
                return 0.0, 1.0, 0.0, 0.0, inward
            tgt = "self" if (s.target == "self" or (s.target is None and s.sel == "self")) else "opp"
            sq = 1.0 if (gp == "aim" and s.target == "opp" and left < 1.2) else 0.0   # прицеливается
            return 1.0, 0.0, sq, 0.0, toward(s.pose_target(tgt)[2])
        hp = P(h, BODY_D * v)
        if s.jackpot and (gp in ("jackpot", "aim") or (gp == "result" and s.pt < 0.9)):
            closed = 1.0 if gp in ("aim", "result") else 0.0   # во время прицеливания зажмуривается
            return 1.0, closed, 0.0, 1.0, toward(hp)           # у соперника джекпот - напуган
        if s.target == "opp":
            if gp == "aim":
                if left < 0.45:
                    return 0.0, 1.0, 0.0, 0.0, inward         # в него целятся - зажмурился
                if left < 1.2:
                    return 1.0, 0.0, 1.0, 0.0, toward(hp)     # за секунду до выстрела прищурился
                return 1.0, 0.0, 0.0, 0.0, toward(hp)
            if gp == "result" and s.pt < 0.9:
                return 0.0, 1.0, 0.0, 0.0, inward
        if s.target == "self" and gp in ("aim", "result"):
            return 1.0, 0.0, 1.0, 0.0, toward(hp)             # щурится: ждёт, когда тот выстрелит в себя
        return 0.0, 0.0, 0.0, 0.0, inward

    def update_eyes(s, dt):
        for i in (0, 1):
            lk, cl, sq, wd, u = s.eye_goals(i)
            e = s.eye[i]
            step = dt * 8.0
            for k, g in ((0, lk), (1, cl), (2, sq), (5, wd)):
                e[k] += max(-step, min(step, g - e[k]))
            f = min(1.0, dt * 10.0)
            ux, uy = e[3] + (u[0] - e[3]) * f, e[4] + (u[1] - e[4]) * f
            d = math.hypot(ux, uy) or 1.0
            e[3], e[4] = ux / d, uy / d

    def _update(s, dt):
        s.t += dt
        s.btn_press = max(0.0, s.btn_press - dt * 5)
        if s.state == "light":
            s.btn_alpha = min(1.0, s.btn_alpha + dt * 3)
            s.phase_t += dt
            if s.phase_t >= s.phase_dur:
                nxt = {"red": "yellow", "yellow": "green", "green": "red"}[s.phase]
                dur = {"yellow": random.uniform(0.9, 1.6),
                       "green": random.uniform(1.2, 2.2),
                       "red": random.uniform(1.6, 3.6)}[nxt]
                s.phase = nxt
                s.phase_t = 0.0
                s.phase_dur = dur
                s.blue = random.random() < 0.25     # кнопка может внезапно стать синей
                s.phase_id += 1
                s.emit_phase()
            s.hist.append((s.t, s.phase, s.blue))
            while len(s.hist) > 2 and s.hist[1][0] < s.t - 0.6:
                s.hist.pop(0)
            if VS_BOT:
                s.bot_think()
        elif s.state == "gun":
            s.flash = max(0.0, s.flash - dt * 6)
            s.shake = max(0.0, s.shake - dt * 2.2)
            if s.gp == "take":
                s.gun_t += dt
                if s.gun_t >= 1.5:
                    s.gp = "choose"
                    s.pt = 0.0
            else:
                s.pt += dt
                s.ext = min(1.0, s.ext + dt / 0.6)
            if s.fired:
                s.since_shot += dt
            goal = 1.0 if s.sel == "self" else 0.0
            step = dt * 3.0
            s.aim_k += max(-step, min(step, goal - s.aim_k))

            if s.gp in ("choose", "jackpot"):
                if VS_BOT and s.holder == 1 - LOCAL_PLAYER:
                    s.bot_gun_think()
            elif s.gp == "aim":
                if s.pt >= s.aim_dur and s.net != "guest":
                    s.resolve()
            elif s.gp == "result":
                if s.fired:
                    if (not s.fatal) and s.pt >= 1.5:
                        s.begin_return()
                elif s.target == "opp":
                    if s.pt >= 1.0:
                        s.begin_return()
                elif s.pt >= 1.2:
                    s.begin_jackpot()              # осечка в себя = ДЖЕКПОТ
            elif s.gp == "return":
                if s.pt >= 2.0 and s.net != "guest":
                    s.start_round()

            if s.state == "gun":
                s.tl = s.timeline()
                s.btn_alpha = s.tl["btn_a"]
                if s.fired and s.since_shot < 0.9:
                    m = muzzle(s.tl["pos"], s.tl["a"], s.tl["scale"])
                    d = gun_axes(s.tl["a"])[0]
                    s.smoke.append([m[0], m[1], random.uniform(0.2, 0.4) * v, 1.0, 1.0,
                                    d[0] * random.uniform(0.5, 1.5) * v + random.uniform(-0.3, 0.3) * v,
                                    d[1] * random.uniform(0.5, 1.5) * v])
                for p in s.smoke:
                    p[3] -= dt
                    p[0] += p[5] * dt
                    p[1] += p[6] * dt
                    p[2] += dt * 0.9 * v
                s.smoke = [p for p in s.smoke if p[3] > 0]

    def key_tap(s):
        """Для клавиатуры (ПК): куда "нажать" на SPACE."""
        if s.state == "title":
            return BTN_PLAY[0], BTN_PLAY[1]
        if s.state == "help":
            return BTN_HBACK[0], BTN_HBACK[1]
        if s.state == "lobby":
            return BTN_FIND[0], BTN_FIND[1]
        if s.state == "gun" and s.gp == "result" and s.fatal and s.pt > 2.2:
            return BTN_AGAIN[0], BTN_AGAIN[1]
        return None

    # ---------- онлайн: хост ведёт матч, гость получает его события ----------
    def send(s, m):
        if s.netobj is not None:
            s.netobj.send(m)

    def emit(s, m):
        if s.net == "host":
            s.send(m)

    def emit_phase(s):
        s.emit({"k": "phase", "p": s.phase, "b": bool(s.blue), "id": s.phase_id})

    def emit_gun(s):
        s.emit({"k": "gun", "h": s.holder, "fs": s.fs, "fm": s.fs_msg})

    def open_lobby(s):
        s.state = "lobby"
        s.lobby_status = ""

    def lobby_find(s):
        if NET.search():
            s.netobj = NET
            s.lobby_status = "searching"
        else:
            s.lobby_status = NET.error

    def lobby_create(s):
        if NET.host():
            s.netobj = NET
            set_mode(True)
            s.state = "waiting"
            s.lobby_status = ""
        else:
            s.lobby_status = NET.error

    def lobby_bot(s):
        if s.netobj is not None:
            NET.close()
        s.netobj = None
        set_mode(False)
        s.lives = [3, 3]
        s.start_round()

    def lobby_back(s):
        if s.netobj is not None:
            NET.close()
        s.netobj = None
        s.lobby_status = ""
        s.state = "title"

    def start_online(s, role):
        set_mode(True)
        s.net = "host" if role == "host" else "guest"
        s.lives = [3, 3]
        s.fs = None
        s.lobby_status = "paired"
        if s.net == "host":
            s.start_round()
        else:
            s.state = "waiting"

    def opponent_left(s):
        """Соперник вышел во время раунда: его анимация смерти, победа засчитывается."""
        NET.close()
        s.netobj = None
        s.net = None
        set_mode(True)
        s.reset_gun_vars()
        s.leave_ask = False
        s.left_msg = True
        s.holder, s.opp = 0, 1
        s.grip = "both"
        s.lv_snap = [s.lives[0], s.lives[1]]
        s.target = "opp"
        s.sel = "opp"
        s.victim = 1
        s.jackpot = False
        s.lives[1] = 0
        s.fired = True
        s.fatal = True
        s.hit_c = P(1, BODY_D * v)
        s.death_side = 1
        s.splat = [(random.uniform(0, math.tau), 1.0 + 5.5 * math.sqrt(random.random()),
                    random.uniform(0.1, 0.5), random.uniform(0.07, 0.18)) for _ in range(64)]
        s.flash = 1.0
        s.shake = 1.0
        s.gp = "result"
        s.pt = 0.0
        s.since_shot = 0.0
        s.ext = 1.0
        s.aim_k = 0.0
        s.state = "gun"
        s.tl = s.timeline()

    def leave_to_menu(s):
        s.my_rev = False
        s.foe_rev = False
        s.rev_dead = False
        if s.netobj is not None:
            NET.close()
        s.netobj = None
        s.net = None
        set_mode(False)
        s.lives = [3, 3]
        s.reset_gun_vars()
        s.phase = None
        s.btn_alpha = 1.0
        s.state = "title"

    def apply_phase(s, m):
        if s.state != "light":
            s.reset_gun_vars()
            s.state = "light"
            s.btn_alpha = 0.0
        s.phase = m["p"]
        s.blue = m["b"]
        s.phase_id = m["id"]
        s.phase_t = 0.0
        s.phase_dur = 1e9                   # гость не переключает свет сам
        s.since = s.t
        s.fs = None
        s.hist = []
        s.bot_plan = None

    def apply_gun(s, m):
        s.fs = None if m["fs"] is None else 1 - m["fs"]
        s.fs_msg = m["fm"]
        s.begin_gun(1 - m["h"])

    def remote_tap(s, t, c):
        if s.holder != 1:
            return
        if s.gp == "jackpot":
            if t == "opp":
                s.confirm("opp")
            return
        if s.gp != "choose":
            return
        if c or s.sel == t:
            s.confirm(t)
        else:
            s.sel = t

    def jackpot_tap(s):
        if s.net == "guest":
            s.send({"k": "tap", "t": "opp", "c": 1})
        else:
            s.confirm("opp")

    def on_net(s, m):
        k = m.get("k")
        if k == "sys":
            e = m.get("e")
            if e == "paired":
                s.start_online("host" if m.get("role") == "host" else "guest")
            elif e == "joining":
                if s.state in ("lobby", "find", "code"):
                    s.state = "waiting"
                    pygame.key.stop_text_input()
            elif e == "nocode":
                NET.close()
                s.netobj = None
                s.state = "code"
                s.code_err = "nocode"
            elif e == "noroom":
                NET.close()
                s.netobj = None
                s.state = "lobby"
                s.lobby_status = "noroom"
            elif e in ("bye", "closed", "noserver") and s.match_over():
                s.match_left()
            elif e in ("bye", "closed", "noserver") and s.net is not None and s.state in ("light", "gun"):
                s.opponent_left()
            elif e in ("bye", "closed", "noserver"):
                in_match = s.netobj is not None or s.net is not None or s.state == "waiting"
                if in_match:
                    NET.close()
                    s.netobj = None
                    s.net = None
                    set_mode(False)
                    s.reset_gun_vars()
                    s.phase = None
                    s.btn_alpha = 1.0
                    s.state = "lobby"
                    s.lobby_status = "bye" if e == "bye" else "noserver"
                elif s.state == "lobby":
                    s.lobby_status = "noserver"
            return
        if k == "rev":
            if s.match_over():
                s.foe_rev = True
                s.rev_check()
            return
        if s.net == "guest":
            if k == "phase":
                s.apply_phase(m)
            elif k == "gun":
                s.apply_gun(m)
            elif k == "conf":
                s.confirm(m["t"], aim=m["a"])
            elif k == "res":
                s.resolve(forced=m["f"])
        elif s.net == "host":
            if k == "press" and s.state == "light":
                s.press(1, lag=REMOTE_LAG)
            elif k == "tap":
                s.remote_tap(m["t"], m.get("c", 0))

    def match_over(s):
        return s.state == "gun" and s.gp == "result" and s.fatal and not s.left_msg

    def rev_check(s):
        """Оба нажали реванш - матч начинается заново."""
        if not (s.my_rev and s.foe_rev):
            return
        s.lives = [3, 3]
        s.my_rev = False
        s.foe_rev = False
        if s.net == "host":
            s.start_round()
        else:
            s.reset_gun_vars()
            s.state = "light"
            s.phase = "red"
            s.phase_dur = 1e9
            s.phase_t = 0.0
            s.since = s.t
            s.btn_alpha = 0.0

    def match_left(s):
        """Соперник ушёл после конца матча: владелец комнаты снова ждёт игрока,
        у гостя кнопка Revenge становится серой."""
        role = NET.role
        s.my_rev = False
        s.foe_rev = False
        NET.close()
        s.netobj = None
        s.net = None
        set_mode(True)
        if role == "host":
            s.lives = [3, 3]
            s.reset_gun_vars()
            s.rev_dead = False
            s.left_msg = False
            s.leave_ask = False
            if NET.host():
                s.netobj = NET
                s.state = "waiting"
            else:
                s.leave_to_menu()
        else:
            s.rev_dead = True

    def try_code(s):
        if not valid_room_code(s.code_text):
            s.code_err = "badcode"
            return
        if NET.join_code(s.code_text):
            s.netobj = NET
            s.code_err = ""
        else:
            s.code_err = "noserver"

    def text_input(s, t):
        if s.state != "code":
            return
        for ch in t.upper():
            i = len(s.code_text)
            if i >= 5:
                break
            if (i in (1, 3) and "0" <= ch <= "9") or (i in (2, 4) and "A" <= ch <= "Z"):
                s.code_text += ch

    def backspace(s):
        if s.state == "code" and len(s.code_text) > 1:
            s.code_text = s.code_text[:-1]

    def drag_to(s, x):
        if s.drag == "music":
            set_music_vol(slider_value(x, SLD_MUSIC))
        elif s.drag == "sfx":
            set_sfx_vol(slider_value(x, SLD_SFX))

    def release(s):
        s.drag = None

    def slow(s):
        """Замедленное время (слоу-мо) в момент смертельного выстрела."""
        if s.state == "gun" and s.fired and s.fatal and s.since_shot < 0.35:
            return 0.3
        return 1.0

    # ---------- позы
    def hold_pt(s):
        h = s.holder
        if s.grip == "left":
            return P(h, 4.8 * v, -1.6 * v)       # здоровая (левая) рука - на уровне своей руки
        if s.grip == "head":
            return P(h, 4.8 * v)                 # пистолет у лица (берёт головой)
        return P(h, 4.8 * v)                     # на уровне рук, где они обычно стоят

    def pose_target(s, which):
        """Рукоять, угол пистолета и точка прицела. 1-я цель - правая кисть, 2-я - левая,
        на последней жизни - тело. Кисти свободно двигаются, пистолет целится ровно в них."""
        h, o = s.holder, s.opp
        lv = s.lv_snap if s.lv_snap else s.lives
        a0 = math.atan2(INW[h], 0)
        hold = s.hold_pt()
        if which == "opp":
            if lv[o] <= 1:
                T = P(o, BODY_D * v)
            else:
                k = 1 if lv[o] >= 3 else 0
                hp = s.player_pose(o)["hands"][k]
                T = hp if hp is not None else (s.hit_c or P(o, 4.8 * v, (1 if k else -1) * 1.6 * v))
            G = lerp_pt(hold, (hold[0], hold[1] + INW[h] * (0.3 if s.grip == "head" else 0.8) * v), ease(s.ext))
            ang = lerp_ang(a0, math.atan2(T[1] - G[1], T[0] - G[0]), ease(s.ext))
        else:
            sg = 1 if lv[h] >= 3 else -1
            if lv[h] <= 1:
                T = P(h, BODY_D * v)                   # в себя (тело)
                G = P(h, 5.3 * v) if s.grip == "head" else P(h, 6.9 * v)
            else:
                T = P(h, 4.6 * v, sg * 2.3 * v)        # в свою кисть, которую выставил вперёд
                G = P(h, 6.3 * v, sg * 1.0 * v)
            ang = math.atan2(T[1] - G[1], T[0] - G[0])
        return G, ang, T

    def timeline(s):
        h = s.holder
        a0 = math.atan2(INW[h], 0)
        center = (CX, CY - INW[h] * 1.1 * v)
        hold = s.hold_pt()
        if s.gp == "take":
            gt = s.gun_t
            take = ease((gt - 0.7) / 0.8)
            e = ease(gt / 0.45)
            return {"pos": lerp_pt(center, hold, take), "a": a0, "scale": GUN_SCALE,
                    "alpha": 255 * ease((gt - 0.25) / 0.4), "btn_a": 1 - e, "btn_s": lerp(1.0, 0.7, e)}
        Go, ao, _ = s.pose_target("opp")
        Gs, as_, _ = s.pose_target("self")
        ke = ease(s.aim_k)
        pos = lerp_pt(Go, Gs, ke)
        ang = lerp_ang(ao, as_, ke)
        scale, alpha, btn_a, btn_s = GUN_SCALE, 255.0, 0.0, 0.7
        if s.gp in ("choose", "jackpot", "aim"):
            if s.gp == "aim":
                amp = lerp(0.02, 0.1, clamp01(s.pt / s.aim_dur)) * v
            else:
                amp = 0.02 * v
            pos = (pos[0] + math.sin(s.t * 41) * amp, pos[1] + math.cos(s.t * 37) * amp)
        elif s.gp == "result":
            if s.fired:
                rc = math.exp(-s.pt * 9) * 0.7 * v
                d = gun_axes(ang)[0]
                pos = (pos[0] - d[0] * rc, pos[1] - d[1] * rc)
        elif s.gp == "return":
            pos0, ang0, sc0 = s.ret_from
            back = ease(s.pt / 0.7)
            pos = lerp_pt(pos0, center, back)
            ang = lerp_ang(ang0, a0, back)
            scale = GUN_SCALE
            alpha = 255 * (1 - ease((s.pt - 0.5) / 0.6))
            btn_a = ease((s.pt - 0.9) / 0.8)
            btn_s = lerp(0.7, 1.0, btn_a)
        return {"pos": pos, "a": ang, "scale": scale, "alpha": alpha, "btn_a": btn_a, "btn_s": btn_s}

    def player_pose(s, i):
        # какие кисти уже оторваны (1-я потеря - правая, 2-я - левая)
        lv_i = s.lives[i]
        if s.fired and i == s.victim and s.since_shot < 0.07 and s.lv_snap:
            lv_i = s.lv_snap[i]                       # до момента попадания кисть ещё на месте
        lost = [lv_i <= 1, lv_i <= 2]                 # [левая, правая]
        rest = []
        for k in (0, 1):
            bx = math.sin(s.t * 1.7 + k * 2.1) * 0.14 * v        # кисти слегка плавают
            by = math.cos(s.t * 1.3 + k * 1.7) * 0.12 * v
            r = P(i, 4.8 * v, (-1.6 if k == 0 else 1.6) * v)
            rest.append((r[0] + bx, r[1] + by))
        pose = {"hands": list(rest), "off": 0.0, "dx": 0.0, "hidden": False, "eye": s.eye[i], "lives": s.lives[i], "t": s.t}

        def finish(hands):
            for k in (0, 1):
                if lost[k]:
                    hands[k] = None
            pose["hands"] = hands
            return pose

        if s.state != "gun" or s.tl is None:
            return finish(list(rest))
        h = s.holder
        if i == h:
            reach = ease((s.gun_t - 0.55) / 0.4) if s.gp == "take" else 1.0
            if s.gp == "return":
                reach *= 1 - ease((s.pt - 1.2) / 0.6)
            gp_ = s.tl["pos"]
            if s.grip == "both":
                tgt = [(gp_[0] - 0.5 * v, gp_[1]), (gp_[0] + 0.5 * v, gp_[1])]
                hands = [lerp_pt(rest[k], tgt[k], reach) for k in (0, 1)]
            elif s.grip == "left":                  # правая оторвана - пистолет у левой кисти
                hands = [lerp_pt(rest[0], gp_, reach), rest[1]]
            else:                                   # обе кисти потеряны - берёт пистолет "лицом"
                hands = [rest[0], rest[1]]
                lean = ease((s.gun_t - 0.7) / 0.8) if s.gp == "take" else 1.0
                if s.gp == "return":
                    lean *= 1 - ease((s.pt - 1.2) / 0.6)
                pose["off"] = lean * 0.5 * v
            # выстрел в себя: выставляет вперёд ту кисть, в которую будет стрелять
            lvh = s.lv_snap[h] if s.lv_snap else s.lives[h]
            if (s.sel == "self" or s.target == "self") and lvh >= 2:
                kt = 1 if lvh >= 3 else 0
                sg = 1 if kt else -1
                hands[kt] = lerp_pt(hands[kt], P(h, 4.6 * v, sg * 2.3 * v), ease(s.aim_k))
        else:
            up = 0.0
            if s.target == "opp" and s.gp in ("aim", "result"):     # цель поднимает руки, когда в неё целятся
                up = ease(s.pt / 0.5) if s.gp == "aim" else 1.0
                if s.gp == "result":
                    if s.fired and s.fatal:
                        up *= 1 - ease((s.pt - 0.05) / 0.2)
                    else:
                        up *= 1 - ease((s.pt - 0.3) / 0.5)
            kk = clamp01(s.pt / s.aim_dur) if s.gp == "aim" else 1.0
            tr = math.sin(s.t * 31) * 0.03 * v * kk * up
            upp = [P(i, 3.6 * v, -2.6 * v + tr), P(i, 3.6 * v, 2.6 * v - tr)]
            hands = [lerp_pt(rest[k], upp[k], up) for k in (0, 1)]
            pose["dx"] = tr * 1.5
            if s.jackpot and s.target == "opp" and s.gp in ("aim", "result"):
                # пытается закрыться руками (не поможет: пистолет целится прямо в них)
                cover = ease(s.pt / 0.5) if s.gp == "aim" else 1.0
                if s.gp == "result":
                    cover *= 1 - ease((s.pt - 0.5) / 0.4)
                cov = [P(i, 3.7 * v, -0.5 * v + tr), P(i, 3.7 * v, 0.5 * v - tr)]
                hands = [lerp_pt(hands[k], cov[k], cover) for k in (0, 1)]
        if s.fired and i == s.victim and s.gp in ("result", "return"):
            st = s.since_shot
            if s.fatal:
                if st >= 0.07:                      # круг лопнул и исчез вместе с кистями
                    pose["hidden"] = True
                    lost = [True, True]
            else:                                   # кисть лопнула - тело вздрагивает
                pose["off"] += math.sin(clamp01(st / 0.8) * math.pi) * 0.5 * v
        return finish(hands)

    # ---------- отрисовка
    def draw(s):
        cv = s.canvas
        cv.blit(s.table, (0, 0))
        gun_on = s.state == "gun" and s.tl is not None

        # кровь (того же цвета, что и сам игрок)
        if gun_on and s.fired and s.since_shot > 0.06 and s.hit_c is not None:
            st = s.since_shot
            bcol = PCOL[s.victim]
            hc0 = s.hit_c
            if s.fatal:
                rmax, sc, tmax, ring_max = 2.7, 1.0, 0.25, 4.2
            else:
                rmax, sc, tmax, ring_max = 0.9, 0.9, 0.22, 1.7
            fade = 1.0
            if (not s.fatal) and s.gp == "return":
                fade = 1 - ease((s.pt - 0.9) / 0.9)
            ci = (int(hc0[0]), int(hc0[1]))
            if 0.07 < st < 0.45:                    # ударная волна взрыва
                kk = (st - 0.07) / 0.38
                pygame.draw.circle(cv, mix(bcol, (255, 255, 255), 0.55), ci,
                                   int((0.4 + ring_max * ease(kk)) * v), max(1, int(0.35 * v * (1 - kk))))
            for ang, dist, rad, delay in s.splat:
                kk = ease((st - delay) / tmax)
                if kk > 0:
                    px = hc0[0] + math.cos(ang) * dist * v * kk * sc
                    py = hc0[1] + math.sin(ang) * dist * v * kk * sc
                    pygame.draw.circle(cv, bcol, (int(px), int(py)),
                                       max(1, int(rad * v * fade * (1 if s.fatal else 0.8))))

        for i in (0, 1):
            if s.state == "waiting" and i != LOCAL_PLAYER:   # соперника ещё нет - не рисуем
                continue
            draw_player(cv, i, s.player_pose(i))

        if gun_on:
            draw_button(cv, s.tl["btn_a"], s.tl["btn_s"], s.btn_press, s.blue)
        else:
            draw_button(cv, s.btn_alpha, 1.0, s.btn_press, s.blue)

        # выбор цели: кольца вокруг голов (видит тот, кто держит пистолет)
        if gun_on and s.gp in ("choose", "jackpot") and s.holder == LOCAL_PLAYER and s.pt > 0.2:
            pulse = 0.5 + 0.5 * math.sin(s.t * 6)
            for tgt in ("opp", "self"):
                if s.gp == "jackpot" and tgt == "self":
                    continue
                pi_ = s.opp if tgt == "opp" else s.holder
                c = s.pose_target(tgt)[2]
                sel = (s.sel == tgt)
                col = (255, 60, 60) if sel else (255, 255, 255)
                r = int(((2.4 if s.lives[pi_] <= 1 else 1.0) + 0.15 * pulse) * v)
                ci = (int(c[0]), int(c[1]))
                pygame.draw.circle(cv, col, ci, r, 5 if sel else 2)
                if sel:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        pygame.draw.line(cv, col, (ci[0] + dx * r * 0.7, ci[1] + dy * r * 0.7),
                                         (ci[0] + dx * r * 1.3, ci[1] + dy * r * 1.3), 4)

        if gun_on:
            tl = s.tl
            draw_gun(cv, tl["pos"], tl["a"], tl["scale"], tl["alpha"])
            m = muzzle(tl["pos"], tl["a"], tl["scale"])
            if s.target is not None and s.gp in ("aim", "result"):
                tgt = s.hit_c if (s.fired and s.hit_c is not None) else s.pose_target(s.target)[2]
                if s.gp == "aim" and s.pt > 0.4:
                    pr = ease((s.pt - 0.4) / 0.6)
                    end = lerp_pt(m, tgt, pr)
                    pygame.draw.line(cv, (255, 40, 40), (int(m[0]), int(m[1])), (int(end[0]), int(end[1])), max(2, int(0.07 * v)))
                    if pr >= 1:
                        kk = clamp01((s.pt - 1.0) / max(0.1, s.aim_dur - 1.0))
                        r = int(lerp(1.5, 0.8, kk) * v)
                        ti = (int(tgt[0]), int(tgt[1]))
                        pygame.draw.circle(cv, (255, 40, 40), ti, r, 3)
                        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                            pygame.draw.line(cv, (255, 40, 40),
                                             (ti[0] + dx * r * 0.6, ti[1] + dy * r * 0.6),
                                             (ti[0] + dx * r * 1.4, ti[1] + dy * r * 1.4), 3)
                        g = glow((255, 40, 40), 1.8 * v)
                        cv.blit(g, g.get_rect(center=ti))
                if s.fired:
                    st = s.since_shot
                    if st < 0.07:
                        b = lerp_pt(m, tgt, st / 0.07)
                        b0 = lerp_pt(m, tgt, max(0, st / 0.07 - 0.25))
                        pygame.draw.line(cv, (255, 245, 200), (int(b0[0]), int(b0[1])), (int(b[0]), int(b[1])), max(2, int(0.12 * v)))
                    if s.flash > 0.3:
                        pts = []
                        for k in range(16):
                            r = (1.5 if k % 2 == 0 else 0.6) * v * s.flash
                            ang = k * math.tau / 16 + 0.3
                            pts.append((m[0] + math.cos(ang) * r, m[1] + math.sin(ang) * r))
                        pygame.draw.polygon(cv, (255, 215, 90), pts)
                        pygame.draw.circle(cv, (255, 255, 240), (int(m[0]), int(m[1])), max(2, int(0.45 * v * s.flash)))
            for p in s.smoke:
                d = max(2, int(p[2] * 2))
                ss = pygame.Surface((d, d), pygame.SRCALPHA)
                pygame.draw.circle(ss, (200, 200, 205, int(110 * p[3] / p[4])), (d // 2, d // 2), d // 2)
                cv.blit(ss, ss.get_rect(center=(int(p[0]), int(p[1]))))

        draw_light(cv, s.phase if s.state == "light" else None)

        ox = oy = 0
        if s.shake > 0:
            ox = int(random.uniform(-1, 1) * s.shake * 0.35 * v)
            oy = int(random.uniform(-1, 1) * s.shake * 0.35 * v)
            screen.fill((0, 0, 0))
        screen.blit(cv, (ox, oy))

        if gun_on:
            inten = 0.0
            if s.gp == "aim":
                kk = s.pt / s.aim_dur
                f = lerp(1.3, 2.6, kk)
                beat = max(0.0, math.sin(math.tau * f * s.t)) ** 6
                inten = (0.25 + 0.55 * kk) * (0.5 + 0.5 * beat)
                s.dark.set_alpha(int(80 * kk))
                screen.blit(s.dark, (0, 0))
            elif s.gp == "result":
                if s.fired:
                    inten = 0.35 if s.fatal else 0.35 * (1 - ease(s.pt / 1.5))
                else:
                    inten = 0.35 * (1 - ease(s.pt / 0.5))
            if inten > 0.01:
                s.vig_red.set_alpha(int(255 * clamp01(inten)))
                screen.blit(s.vig_red, (0, 0))
            if s.flash > 0 and s.fired:
                s.white.set_alpha(int(200 * s.flash))
                screen.blit(s.white, (0, 0))

        s.draw_texts()
        s.draw_overlay()
        pygame.display.flip()

    def draw_overlay(s):
        sc = screen
        if s.netobj is not None and NET.room and s.state in ("waiting", "light", "gun"):
            lbl = f"{tr('room_lbl')}: {NET.room}"
            text(sc, lbl, v * 0.5, (200, 200, 200), (W - 0.4 * v - 0.3 * v * len(lbl) / 2, H - 0.5 * v))
        if s.state in ("light", "gun", "waiting") and not s.leave_ask:
            ui_button(sc, *BTN_BACKGAME, tr("back"), (120, 60, 60))
        if s.leave_ask:
            s.dark.set_alpha(190)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("leave_q"), v * 1.2, (255, 220, 90), (CX, CY - 1.2 * v))
            ui_button(sc, *BTN_YES, tr("yes"), (190, 55, 55))
            ui_button(sc, *BTN_NO, tr("no"), (60, 110, 190))

    def draw_texts(s):
        sc = screen

        def fl(i):                              # переворачивать текст, если игрок сидит сверху
            return 1 if INW[i] == 1 else 0

        def mine(i):                            # показываем только свои тексты
            return LOCAL_PLAYER is None or LOCAL_PLAYER == i

        def lang_btn():
            ui_button(sc, *BTN_LANG, "EN" if LANG == "en" else "RU", (70, 90, 160))

        WHITE = (255, 255, 255)
        GOLD = (255, 215, 60)
        pulse_a = 150 + 100 * (0.5 + 0.5 * math.sin(s.t * 4))

        if s.state == "title":
            s.dark.set_alpha(150)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("title1"), v * 2.6, (255, 220, 90), (TITLE_X, CY - 1.6 * v))
            text(sc, tr("title2"), v * 2.6, (255, 220, 90), (TITLE_X, CY + 1.2 * v))
            vt = "Version: Alpha-1-0"
            text(sc, vt, v * 0.45, (170, 170, 170), (W - 0.5 * v - 0.3 * v * len(vt) / 2, H - 0.5 * v))
            ui_button(sc, *BTN_PLAY, tr("play"), (40, 160, 80))
            ui_button(sc, *BTN_HELP, tr("settings"), (60, 110, 190))
            ui_button(sc, *BTN_EXIT, tr("exit"), (190, 55, 55))
            lang_btn()
            return

        if s.state == "settings":
            s.dark.set_alpha(190)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("settings"), v * 1.6, (255, 220, 90), (CX, 1.8 * v))
            draw_slider(sc, SLD_MUSIC, tr("music"), MUSIC_VOL)
            draw_slider(sc, SLD_SFX, tr("sound"), SFX_VOL)
            ui_button(sc, *BTN_SHELP, tr("help"), (60, 110, 190))
            ui_button(sc, *BTN_SBACK, tr("back"), (190, 55, 55))
            return

        if s.state == "find":
            s.dark.set_alpha(150)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("find"), v * 2.0, (255, 220, 90), (TITLE_X, CY - 1.6 * v))
            ui_button(sc, *BTN_FIND, tr("join_any"), (40, 160, 80))
            ui_button(sc, *BTN_CREATE, tr("join_code"), (60, 110, 190))
            ui_button(sc, *BTN_LBACK, tr("back"), (190, 55, 55))
            return

        if s.state == "code":
            s.dark.set_alpha(150)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("enter_code"), v * 0.7, WHITE, (MENU_X, CY - 4.6 * v))
            fx, fy, fw, fh = FIELD_RECT
            pygame.draw.rect(sc, (30, 30, 36), pygame.Rect(int(fx - fw / 2), int(fy - fh / 2), int(fw), int(fh)),
                             border_radius=int(0.4 * v))
            text(sc, s.code_text + "_", v * 1.2, WHITE, (fx, fy))
            ui_button(sc, *BTN_CONNECT, tr("connect"), (40, 160, 80))
            ui_button(sc, *BTN_LBACK, tr("back"), (190, 55, 55))
            if s.code_err:
                text(sc, tr(s.code_err), v * 0.8, (255, 120, 120), (TITLE_X, CY + 0.6 * v))
            return

        if s.state == "lobby":
            s.dark.set_alpha(150)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("lobby_title"), v * 2.0, (255, 220, 90), (TITLE_X, CY - 1.6 * v))
            if s.lobby_status:
                text(sc, tr(s.lobby_status), v * 0.8, WHITE, (TITLE_X, CY + 0.6 * v), alpha=pulse_a)
            ui_button(sc, *BTN_FIND, tr("find"), (190, 130, 30))
            ui_button(sc, *BTN_CREATE, tr("create"), (40, 160, 80))
            ui_button(sc, *BTN_VSBOT, tr("vs_bot"), (60, 110, 190))
            ui_button(sc, *BTN_LBACK, tr("back"), (190, 55, 55))
            return

        if s.state == "help":
            s.dark.set_alpha(190)
            sc.blit(s.dark, (0, 0))
            text(sc, tr("helpt"), v * 1.5, (255, 220, 90), (CX, 1.8 * v))
            for k, key in enumerate(("r1", "r2", "r3", "r4", "r5", "r6", "r7", "r8")):
                text(sc, tr(key), v * 0.62, WHITE, (CX, (3.7 + 1.05 * k) * v))
            ui_button(sc, *BTN_HBACK, tr("back"), (70, 90, 160))
            return

        # имена и жизни: свои - в левом нижнем углу, соперника - над его головой
        me = LOCAL_PLAYER if LOCAL_PLAYER is not None else 0
        foe = 1 - me
        names = {me: tr("player"), foe: tr("opponent") if ONLINE else tr("bot")}

        def hud(i, cx, hy, ny):
            text(sc, names[i], v * 0.75, mix(PCOL[i], WHITE, 0.45), (cx, ny))
            for k in range(3):
                draw_heart(sc, cx + (k - 1) * 1.4 * v, hy, 0.5 * v,
                           (235, 50, 70) if k < s.lives[i] else (85, 42, 50))

        hud(me, 2.6 * v, H - 1.7 * v, H - 2.8 * v)
        if s.state != "waiting":
            hud(foe, CX, 1.35 * v, 0.45 * v)                # над головой соперника: имя сверху, сердечки под ним

        if s.state == "waiting":
            if NET.role == "guest":
                key = "waiting_guest" if NET.paired else "joining"
            else:
                key = "waiting_host"
            text(sc, tr(key), v * 0.9, WHITE, (CX, CY - 1.0 * v), alpha=pulse_a)
            if NET.role == "guest":
                ui_button(sc, *BTN_CANCEL, tr("cancel"), (190, 55, 55))
            return
        if s.state == "light":
            for i in (0, 1):
                if not mine(i):
                    continue
                if s.phase == "red":
                    text(sc, tr("wait"), v * 1.0, RED, side_pos(i, 3.0), fl(i))
                elif s.phase == "yellow":
                    text(sc, tr("getready"), v * 1.0, YEL, side_pos(i, 3.0), fl(i))
                else:
                    text(sc, tr("go"), v * 1.7, GRN, side_pos(i, 3.0), fl(i))
            return

        if s.state != "gun":
            return
        h, o, gp = s.holder, s.opp, s.gp

        tt = s.gun_t if gp == "take" else (1.5 + s.pt if gp == "choose" else 99)
        if tt < 2.2:
            a = 255 * (1 - ease((tt - 1.6) / 0.6))
            if s.fs is not None and mine(s.fs):
                text(sc, tr(s.fs_msg), v * 1.5, RED, side_pos(s.fs, 3.0), fl(s.fs), alpha=a)
            if mine(h):
                msg = tr("foe_mistake") if s.fs is not None else tr("faster")
                text(sc, msg, v * 1.1, GRN, side_pos(h, 3.0), fl(h), alpha=a)
                if s.grip == "left":
                    text(sc, tr("left_hand"), v * 0.75, WHITE, side_pos(h, 4.2), fl(h), alpha=a)
                elif s.grip == "head":
                    text(sc, tr("head_grip"), v * 0.7, WHITE, side_pos(h, 4.2), fl(h), alpha=a)

        if gp == "choose" and tt >= 1.9:
            if mine(h):
                sel = s.sel
                text(sc, tr("to_foe"), v * 0.8, (255, 90, 90) if sel == "opp" else WHITE,
                     P(o, BODY_D * v - 0.9 * v), fl(h))
                lab = tr("to_self_head") if s.lives[h] <= 1 else tr("to_self_arm")
                text(sc, lab, v * 0.8, (255, 90, 90) if sel == "self" else WHITE,
                     P(h, BODY_D * v - 0.9 * v), fl(h))
                prompt = tr("choose") if sel is None else tr("tapagain")
                text(sc, prompt, v * 0.9, GOLD, side_pos(h, 3.0), fl(h), alpha=pulse_a)
            if mine(o):
                text(sc, tr("foe_choose"), v * 0.7, WHITE, side_pos(o, 3.0), fl(o), alpha=pulse_a)

        if gp == "jackpot":
            if mine(h):
                text(sc, tr("jackpot"), v * 1.9, GOLD, side_pos(h, 3.4), fl(h))
                text(sc, tr("jackpot_tap"), v * 0.85, WHITE, side_pos(h, 4.7), fl(h), alpha=pulse_a)
            if mine(o):
                text(sc, tr("jackpot_foe"), v * 0.85, RED, side_pos(o, 3.2), fl(o))

        if gp == "result":
            if not s.fired:
                span = (0.3, 0.7) if s.target == "opp" else (0.4, 0.8)
                a = 255 * (1 - ease((s.pt - span[0]) / span[1]))
                for i in (0, 1):
                    if mine(i):
                        text(sc, tr("click"), v * 1.5, WHITE, side_pos(i, 3.0), fl(i), alpha=a)
            elif not s.fatal:
                if s.pt >= 0.1:
                    a = 255 * (1 - ease((s.pt - 1.0) / 0.5))
                    if s.victim == o:
                        if mine(h):
                            text(sc, tr("hit"), v * 1.7, GOLD, side_pos(h, 3.0), fl(h), alpha=a)
                        if mine(o):
                            text(sc, tr("minus"), v * 1.4, RED, side_pos(o, 3.0), fl(o), alpha=a)
                    else:
                        if mine(h):
                            text(sc, tr("minus"), v * 1.4, RED, side_pos(h, 3.0), fl(h), alpha=a)
                        if mine(o):
                            text(sc, tr("selfhurt"), v * 1.0, GOLD, side_pos(o, 3.0), fl(o), alpha=a)
            else:
                win = 1 - s.victim
                if s.pt > 0.8:                  # ПОБЕДА / ПОРАЖЕНИЕ - наверху стола
                    if mine(win):
                        text(sc, tr("win"), v * 2.0, GOLD, (CX, CY - 3.7 * v))
                    if mine(s.victim):
                        text(sc, tr("lose"), v * 1.8, RED, (CX, CY - 3.7 * v))
                if s.left_msg and s.pt > 0.8:
                    text(sc, tr("opp_left"), v * 0.8, WHITE, (CX, CY - 2.5 * v))
                if s.pt > 2.2:
                    if ONLINE:
                        if s.my_rev:
                            text(sc, names[me], v * 0.6, WHITE, (CX, CY - 2.7 * v))
                        if s.foe_rev:
                            text(sc, names[foe], v * 0.6, WHITE, (CX, CY - 2.1 * v))
                        grey = s.rev_dead
                        ui_button(sc, *BTN_AGAIN, tr("revenge"), (70, 70, 70) if grey else (40, 160, 80))
                    else:
                        ui_button(sc, *BTN_AGAIN, tr("again"), (40, 160, 80))
                    ui_button(sc, *BTN_MENU, tr("menu"), (70, 90, 160))


def quit_game():
    pygame.quit()
    sys.exit()


def who(y):
    """Какой игрок нажал."""
    if VS_BOT or ONLINE:
        return LOCAL_PLAYER
    if INPUT_BY_HALF:
        bottom = 0 if INW[0] == -1 else 1
        return bottom if y >= H / 2 else 1 - bottom
    return LOCAL_PLAYER


def drain_net(g):
    """Применяет сетевые сообщения текущей сессии (старые соединения отбрасываются)."""
    while True:
        try:
            m = NET_Q.get_nowait()
        except queue.Empty:
            return
        if m.get("_s") != NET.session:
            continue
        g.on_net(m)


def main():
    load_sounds()
    play_music()
    g = Game()
    back_key = getattr(pygame, "K_AC_BACK", None)
    ev_bg = getattr(pygame, "APP_WILLENTERBACKGROUND", None)
    ev_fg = getattr(pygame, "APP_DIDENTERFOREGROUND", None)
    while True:
        dt = min(clock.tick(60) / 1000.0, 0.05)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                quit_game()
            elif ev_bg is not None and e.type == ev_bg:
                while True:                  # приложение свернули: ждём возвращения
                    e2 = pygame.event.wait()
                    if e2.type == pygame.QUIT:
                        quit_game()
                    if ev_fg is not None and e2.type == ev_fg:
                        break
                clock.tick()
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE or (back_key is not None and e.key == back_key):
                    quit_game()
                elif e.key == pygame.K_SPACE:
                    kt = g.key_tap()
                    if kt:
                        g.press(who(H), x=kt[0], y=kt[1])
                    else:
                        g.press(who(H), y=H)
                elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    g.press(who(0), y=0)
                elif e.key == pygame.K_BACKSPACE:
                    g.backspace()
            elif e.type == pygame.TEXTINPUT:
                g.text_input(e.text)
            elif e.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
                g.release()
            elif e.type == pygame.FINGERMOTION:
                g.drag_to(e.x * W)
            elif e.type == pygame.MOUSEMOTION and e.buttons[0]:
                g.drag_to(e.pos[0])
            elif e.type == pygame.FINGERDOWN:
                g.press(who(e.y * H), x=e.x * W, y=e.y * H)
            elif e.type == pygame.MOUSEBUTTONDOWN and not getattr(e, "touch", False):
                g.press(who(e.pos[1]), x=e.pos[0], y=e.pos[1])
        drain_net(g)
        g.update(dt * g.slow())
        g.draw()


if __name__ == "__main__":
    main()
